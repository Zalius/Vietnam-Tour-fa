import { betterAuth } from "better-auth"
import { Pool } from "pg"

const baseURL =
  process.env.BETTER_AUTH_URL ||
  (process.env.VERCEL_PROJECT_PRODUCTION_URL
    ? `https://${process.env.VERCEL_PROJECT_PRODUCTION_URL}`
    : process.env.VERCEL_URL
      ? `https://${process.env.VERCEL_URL}`
      : process.env.V0_RUNTIME_URL || "http://localhost:3000")

const trustedOrigins = [
  baseURL,
  process.env.V0_RUNTIME_URL,
  process.env.VERCEL_URL ? `https://${process.env.VERCEL_URL}` : undefined,
  process.env.VERCEL_PROJECT_PRODUCTION_URL
    ? `https://${process.env.VERCEL_PROJECT_PRODUCTION_URL}`
    : undefined,
  "http://localhost:3000",
  "http://127.0.0.1:3000",
  // v0 preview + Vercel preview domains (wildcards are matched against the request origin)
  "https://*.vusercontent.net",
  "https://*.v0.dev",
  "https://*.v0.app",
  "https://*.vercel.app",
].filter(Boolean) as string[]

const isHttpsBaseUrl = baseURL.startsWith("https://")

export const auth = betterAuth({
  baseURL,
  trustedOrigins,
  secret: process.env.BETTER_AUTH_SECRET,
  database: new Pool({ connectionString: process.env.DATABASE_URL }),
  emailAndPassword: {
    enabled: true,
  },
  ...(process.env.NODE_ENV === "development"
    ? {
        advanced: {
          defaultCookieAttributes: {
            sameSite: isHttpsBaseUrl ? ("none" as const) : ("lax" as const),
            secure: isHttpsBaseUrl,
          },
        },
      }
    : {}),
})
