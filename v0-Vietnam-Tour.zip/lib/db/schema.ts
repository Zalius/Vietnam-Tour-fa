import {
  pgTable,
  text,
  timestamp,
  boolean,
  serial,
  integer,
  jsonb,
  primaryKey,
} from "drizzle-orm/pg-core"

export const user = pgTable("user", {
  id: text("id").primaryKey(),
  name: text("name").notNull(),
  email: text("email").notNull().unique(),
  emailVerified: boolean("emailVerified").default(false).notNull(),
  image: text("image"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().notNull(),
})

export const session = pgTable("session", {
  id: text("id").primaryKey(),
  expiresAt: timestamp("expiresAt").notNull(),
  token: text("token").notNull().unique(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().notNull(),
  ipAddress: text("ipAddress"),
  userAgent: text("userAgent"),
  userId: text("userId")
    .notNull()
    .references(() => user.id, { onDelete: "cascade" }),
})

export const account = pgTable("account", {
  id: text("id").primaryKey(),
  accountId: text("accountId").notNull(),
  providerId: text("providerId").notNull(),
  userId: text("userId")
    .notNull()
    .references(() => user.id, { onDelete: "cascade" }),
  accessToken: text("accessToken"),
  refreshToken: text("refreshToken"),
  idToken: text("idToken"),
  accessTokenExpiresAt: timestamp("accessTokenExpiresAt"),
  refreshTokenExpiresAt: timestamp("refreshTokenExpiresAt"),
  scope: text("scope"),
  password: text("password"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().notNull(),
})

export const verification = pgTable("verification", {
  id: text("id").primaryKey(),
  identifier: text("identifier").notNull(),
  value: text("value").notNull(),
  expiresAt: timestamp("expiresAt").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().notNull(),
})

export type ItineraryDay = {
  day: number
  title: string
  description: string
}

export type AboutValue = {
  title: string
  body: string
}

export const tours = pgTable("tours", {
  id: serial("id").primaryKey(),
  slug: text("slug").notNull().unique(),
  title: text("title").notNull(),
  region: text("region").notNull(),
  summary: text("summary").default("").notNull(),
  description: text("description").default("").notNull(),
  price: integer("price").default(0).notNull(),
  durationDays: integer("duration_days").default(1).notNull(),
  startLocation: text("start_location").default("").notNull(),
  endLocation: text("end_location").default("").notNull(),
  maxGroupSize: integer("max_group_size").default(12).notNull(),
  difficulty: text("difficulty").default("متوسط").notNull(),
  mainImage: text("main_image").default("").notNull(),
  gallery: jsonb("gallery").$type<string[]>().default([]).notNull(),
  highlights: jsonb("highlights").$type<string[]>().default([]).notNull(),
  included: jsonb("included").$type<string[]>().default([]).notNull(),
  itinerary: jsonb("itinerary").$type<ItineraryDay[]>().default([]).notNull(),
  featured: boolean("featured").default(false).notNull(),
  published: boolean("published").default(true).notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
})

export const aboutPage = pgTable("about_page", {
  id: serial("id").primaryKey(),
  slug: text("slug").default("main").notNull().unique(),
  heroEyebrow: text("hero_eyebrow").default("درباره ما").notNull(),
  heroTitle: text("hero_title")
    .default("سفرهایی فکرشده، ساخته‌شده توسط کسانی که ویتنام را می‌شناسند.")
    .notNull(),
  heroImage: text("hero_image")
    .default("/images/Vietnam/Ha_Long_Bay_2.jpg")
    .notNull(),
  introEyebrow: text("intro_eyebrow").default("تور ویتنام").notNull(),
  introTitle: text("intro_title")
    .default(
      "ما تورها را بر اساس مکان‌های واقعی، زمان‌بندی درست و مراقبت محلی می‌سازیم.",
    )
    .notNull(),
  introBody: jsonb("intro_body").$type<string[]>().default([]).notNull(),
  values: jsonb("values").$type<AboutValue[]>().default([]).notNull(),
  featureEyebrow: text("feature_eyebrow").default("شیوه کار ما").notNull(),
  featureTitle: text("feature_title")
    .default("برنامه‌های روشن، راهنماهای محلی و فضای کافی برای اتفاق‌های خوب.")
    .notNull(),
  featureBody: text("feature_body").default("").notNull(),
  featureImage: text("feature_image")
    .default(
      "/images/Vietnam/lanterns-hoi-an-danang-vietnam-travel-solo-main-image-hd-op.jpg",
    )
    .notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
})

export const hotels = pgTable("hotels", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  city: text("city").notNull(),
  quality: text("quality").default("4 ستاره").notNull(),
  address: text("address").default("").notNull(),
  website: text("website").default("").notNull(),
  phone: text("phone").default("").notNull(),
  image: text("image").default("").notNull(),
  gallery: jsonb("gallery").$type<string[]>().default([]).notNull(),
  description: text("description").default("").notNull(),
  amenities: jsonb("amenities").$type<string[]>().default([]).notNull(),
  notes: text("notes").default("").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
})

export const tourHotels = pgTable(
  "tour_hotels",
  {
    tourId: integer("tour_id")
      .notNull()
      .references(() => tours.id, { onDelete: "cascade" }),
    hotelId: integer("hotel_id")
      .notNull()
      .references(() => hotels.id, { onDelete: "cascade" }),
    createdAt: timestamp("created_at").defaultNow().notNull(),
  },
  (table) => ({
    pk: primaryKey({ columns: [table.tourId, table.hotelId] }),
  }),
)

export type Tour = typeof tours.$inferSelect
export type NewTour = typeof tours.$inferInsert
export type AboutPage = typeof aboutPage.$inferSelect
export type Hotel = typeof hotels.$inferSelect
export type NewHotel = typeof hotels.$inferInsert
